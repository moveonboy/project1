package org.glyco;

public class Enzyme {
	private char name;
	private char ecNO;
	
	public char getName() {
		return name;
	}
	public void setName(char name) {
		this.name = name;
	}
	public char getEcNO() {
		return ecNO;
	}
	public void setEcNO(char ecNO) {
		this.ecNO = ecNO;
	}

}
